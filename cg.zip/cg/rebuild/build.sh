#!/bin/sh

#Read Customer config properties
chmod +x build.conf
source build.conf

#System config properties
entitlementsPlist=base/Entitlements.plist
baseAppName=EmpBridge
baseAppDir=Payload/${baseAppName}.app
targetDir=target
targetIPA=$targetDir/${targetName}.ipa
infoPlist=$baseAppDir/info.plist
publishPlist=$targetDir/${targetName}.plist
PlistBuddy="/usr/libexec/PlistBuddy"

function checkStatus {
	if [ $? -ne 0 ]; then
		echo "Had an Error, aborting!"
		exit 1
	fi
}

# Unzip the old ipa...
rm -r Payload 2> /dev/null | true
unzip -q "base/${baseAppName}.ipa" -d .

echo "Remove the old code signature..."
rm -r "$baseAppDir/_CodeSignature" "$baseAppDir/CodeResources" 2> /dev/null | true
checkStatus

echo "Copy apps, clientConfig and icons..."
cp -r icons/. $baseAppDir
rm -r $baseAppDir/EmpRes/systemTemplate/apps
cp -r apps/. $baseAppDir/EmpRes/systemTemplate/apps
cp -f clientConfig.xml $baseAppDir/EmpRes/systemTemplate/template/config
checkStatus

echo "Update info.plist with bundleId and bundleName..."
$PlistBuddy -c "Set :CFBundleIdentifier $bundleId" $infoPlist
$PlistBuddy -c "Set :CFBundleDisplayName $bundleDisplayName" $infoPlist
$PlistBuddy -c "Set :CFBundleVersion $bundleVersion" $infoPlist
if [ "$xcodeVersion" != "" ]; then
	$PlistBuddy -c "Set :DTXcode $xcodeVersion" $infoPlist
fi
if [ "$xcodeBuildVersion" != "" ]; then
	$PlistBuddy -c "Set :DTXcodeBuild $xcodeBuildVersion" $infoPlist
fi
checkStatus

echo "Replace embedded mobile provisioning profile"
cp $provisionFile "$baseAppDir/embedded.mobileprovision"

echo "Update Entitlements.plist..."
profilePrefix=`grep '<key>application-identifier</key>' "$provisionFile" -A 1 --binary-files=text | sed -E -e '/<key>/ d' -e 's/(^.*<string>)//' -e 's/([A-Z0-9]*)(.*)/\1/'`
$PlistBuddy -c "Set :application-identifier ${profilePrefix}.${bundleId}" $entitlementsPlist
$PlistBuddy -c "Set :keychain-access-groups:0 ${profilePrefix}.${bundleId}" $entitlementsPlist
$PlistBuddy -c "Delete :aps-environment" $entitlementsPlist 2> /dev/null | true
if [ "$enableNotification" == "true" ]; then
	$PlistBuddy -c "Add :aps-environment string production" $entitlementsPlist
fi
checkStatus

#echo "Generate entitlements.plist"
#codesign -d --entitlements :Entitlements.plist $baseAppDir/

echo "Re-sign"
export CODESIGN_ALLOCATE=/Applications/Xcode.app/Contents/Developer/Platforms/iPhoneOS.platform/Developer/usr/bin/codesign_allocate
codesign -f -s "$codeSignIdentity" --resource-rules "$baseAppDir/ResourceRules.plist" --entitlements "$entitlementsPlist" "$baseAppDir"
checkStatus
codesign -f -s "$codeSignIdentity" "$baseAppDir/SangforSDK.dylib"
checkStatus

echo "Re-package IPA..."
mkdir $targetDir 2> /dev/null | true
zip -qr "$targetIPA" Payload
#xcrun -sdk iphoneos PackageApplication -v "$baseAppDir" -o "${PWD}/$targetIPA" --embed "$provisionFile"
rm -r Payload 2> /dev/null | true 

echo "Generate publish plist..."
cp -f base/${baseAppName}.plist $publishPlist
#Remove last character "/" of $publistUrl if exists
case $publishUrl in
     */) publishUrl="${publishUrl%/}";;
#     *) echo not doing anything;;
esac
$PlistBuddy -c "Set :items:0:assets:0:url $publishUrl/$targetName.ipa" $publishPlist
$PlistBuddy -c "Set :items:0:assets:1:url $publishUrl/114x114.png" $publishPlist
$PlistBuddy -c "Set :items:0:assets:2:url $publishUrl/57x57.png" $publishPlist
$PlistBuddy -c "Set :items:0:metadata:bundle-identifier $bundleId" $publishPlist
$PlistBuddy -c "Set :items:0:metadata:bundle-version $bundleVersion" $publishPlist
$PlistBuddy -c "Set :items:0:metadata:title $bundleDisplayName" $publishPlist
checkStatus

echo "Build successfully."
